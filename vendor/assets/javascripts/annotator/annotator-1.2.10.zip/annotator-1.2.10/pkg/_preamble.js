
/*
** Annotator v1.2.10
** https://github.com/okfn/annotator/
**
** Copyright 2015, the Annotator project contributors.
** Dual licensed under the MIT and GPLv3 licenses.
** https://github.com/okfn/annotator/blob/master/LICENSE
**
** Built at: 2015-02-26 03:26:47Z
 */


//# sourceMappingURL=_preamble.map
