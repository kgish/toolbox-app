Welcome to Annotator's documentation!
=====================================

.. highlight:: js

Contents:

.. toctree::
   :maxdepth: 2

   getting-started
   annotation-format
   authentication
   storage
   internationalization

   plugins/index
   hacking/plugin-development

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
