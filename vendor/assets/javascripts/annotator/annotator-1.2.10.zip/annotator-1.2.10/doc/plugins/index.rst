Plugins
=======

Annotator has a highly modular architecture, and a great deal of functionality
is provided by plugins. These pages document these plugins and how they work
together.

.. toctree::
   :glob:
   :maxdepth: 1

   *
